	
	// JavaScript Document
	// ADD Category
	function addCategory(){
		window.location.href = 'index.php?view=add';
	}
	// Order Detail
	function odDetail(OdId){
		window.location.href = 'index.php?view=detail&OdId=' + OdId;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	