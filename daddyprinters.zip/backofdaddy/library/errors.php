<?php
$error[0]	=	"Warning! You can't add duplicate record";
$error[1]	=	"Conflict! This faculty member already have the leacuter at same day and same time";
$error[2]	=	"Conflict! This B Form Or Student CNIC Already Exist Please Enter Correct CNIC Of This Student";
$error[3]	=	"Conflict! Father CNIC Not Exist OR You Enter Wrong CNIC Please Enter Correct CNIC";
$error[4]	=	"Conflict! Teacher CNIC Already Exist OR You Enter Wrong CNIC Please Enter Correct CNIC";
$error['forbidden']	=	"Forbidden: You are not autorized";
$error['sorry']	=	"Sorry: You are already Genrated Challan of this Class & Section For This Month";



?> 