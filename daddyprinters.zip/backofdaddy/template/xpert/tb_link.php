

	<!-- Basic Page Needs
	================================================== -->
	<meta name="description" content="Free Html5 Templates and Free Responsive Themes Designed by Kimmy | zerotheme.com">
    <!-- Mobile Specific Metas
	================================================== -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <!-- CSS
	================================================== -->
  	<link rel="stylesheet" href="<?php echo WEB_ROOT_TEMPLATE;  ?>/table/css/zerogrid.css" media="all">
     <!-- Responsive Table
	================================================== -->
    <link rel="stylesheet" href="<?php echo WEB_ROOT_TEMPLATE;  ?>/table/css/tablesaw.css" media="all">
	<link rel="stylesheet" href="<?php echo WEB_ROOT_TEMPLATE;  ?>/table/css/demo.css" media="all">

	<!--[if lt IE 9]><script src="table/respond.js"></script><![endif]-->
	<script src="<?php echo WEB_ROOT_TEMPLATE;  ?>/table/js/dependencies/jquery.js"></script>
	<script src="<?php echo WEB_ROOT_TEMPLATE;  ?>/table/js/tablesaw.js"></script>
	<script src="http://daddyprinters.com/backofdaddy/template/xpert/dist/js/printThis.js"></script>

    <!-- Responsive Table
  ================================================== -->
	