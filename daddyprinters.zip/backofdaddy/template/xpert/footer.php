	
	
	<footer class="main-footer">
        <strong>&copy; <?php echo date('Y');?> Copyrights. All Rights Reserved
			A Project of <a href="http://daddyprinters.com/" target="_blank">Daddy Printers</a>.</strong>
    </footer>